#ifndef MAIN_H
#define MAIN_H


#define ON         		1					
#define OFF			0		

#endif
