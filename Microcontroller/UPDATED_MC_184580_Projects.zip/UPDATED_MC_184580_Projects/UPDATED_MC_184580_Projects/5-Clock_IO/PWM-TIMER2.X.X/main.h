#ifndef MAIN_H
#define MAIN_H

#include <xc.h>
#include "init_CCP_config.h"
#include "init_timer2_config.h"

#endif