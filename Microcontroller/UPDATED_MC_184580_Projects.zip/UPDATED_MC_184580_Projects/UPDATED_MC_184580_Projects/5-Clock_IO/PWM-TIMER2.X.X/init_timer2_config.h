#ifndef INIT_TIMER2_CONFIG_H
#define INIT_TIMER2_CONFIG_H

void init_timer2_config(void);

#endif