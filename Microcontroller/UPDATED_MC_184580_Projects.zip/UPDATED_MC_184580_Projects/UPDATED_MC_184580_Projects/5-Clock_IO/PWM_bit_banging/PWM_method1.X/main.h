#ifndef MAIN_H
#define MAIN_H

#define CP				RB0

#endif
