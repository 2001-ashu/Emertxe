/* 
 * File:   pwm.h
 * Author: Adil
 *
 * Created on 8 May, 2020, 6:23 PM
 */

#ifndef PWM_H
#define	PWM_H
void init_pwm(void);
void set_pwm_duty(unsigned char duty);
#endif	/* PWM_H */

