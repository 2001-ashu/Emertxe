#ifndef MAIN_H
#define MAIN_H

#define LED1				RB0

#endif
